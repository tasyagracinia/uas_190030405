package com.example.skincare;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    TextView tvskincare;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        tvskincare= findViewById(R.id.tv_nama);
        tvskincare.setText(getIntent().getStringExtra( "Nama"));
        tvskincare=findViewById(R.id.tv_harga);
        tvskincare.setText(getIntent().getStringExtra("Harga"));
    }
}